# -*- coding: utf-8 -*-
# import openpyxl
# from skb_project.adv_search.config_API import staticConfig
# import urllib3
# urllib3.disable_warnings()
#
# staticConfig=staticConfig()['tradeMarkInventoryCategory']
# level1_num_api=len(staticConfig)
#
# file='二级选项.xlsx'
# data=openpyxl.load_workbook(file)
# sheet_last=data['商标商品服务']
#
# # a=sheet_last['J2'].value
# # print(a[-1])
#
# for i in range(2,518):
#     a=sheet_last['J'+str(i)].value
#     sheet_last['J'+str(i)].value=a.rstrip()
# data.save(file)

print('1')